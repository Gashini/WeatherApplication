package com.example.weatherapplication;

import java.util.List;

public class WeatherResponse {
   // @SerializedName("main")
    public Main main;

   // @SerializedName("weather")
    public List<Weather> weather;

    public class Main {
        // @SerializedName("temp")
        public float temp;

       // @SerializedName("humidity")
        public int humidity;
    }

    public class Weather {
     //   @SerializedName("description")
        public String description;
    }
}
