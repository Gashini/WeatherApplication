package com.example.weatherapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private EditText cityInput;
    private Button fetchWeatherButton;
    private TextView geoLocation, currentTime, weatherDescription, temperature, humidity;
    private CardView weatherCard;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityInput = findViewById(R.id.cityInput);
        fetchWeatherButton = findViewById(R.id.fetchWeatherButton);
        geoLocation = findViewById(R.id.geoLocation);
        currentTime = findViewById(R.id.currentTime);
        weatherDescription = findViewById(R.id.weatherDescription);
        temperature = findViewById(R.id.temperature);
        humidity = findViewById(R.id.humidity);
        weatherCard = findViewById(R.id.weatherCard);
        sharedPreferences = getSharedPreferences("WeatherApp", MODE_PRIVATE);

        // Display current time
        updateCurrentTime();

        // Load last searched city
        String lastCity = sharedPreferences.getString("lastCity", null);
        if (lastCity != null) {
            cityInput.setText(lastCity);
            fetchWeatherData(lastCity);
        }

        fetchWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cityName = cityInput.getText().toString();
                if (!cityName.isEmpty()) {
                    fetchWeatherData(cityName);
                    saveLastSearchedCity(cityName);
                }
            }
        });
    }

    private void updateCurrentTime() {
        String currentTimeString = DateFormat.getDateTimeInstance().format(new Date());
        currentTime.setText(currentTimeString);
    }

    private void saveLastSearchedCity(String city) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("lastCity", city);
        editor.apply();
    }

    private void fetchWeatherData(String city) {
        WeatherService weatherService = ApiClient.getRetrofitInstance().create(WeatherService.class);
        Call<WeatherResponse> call = weatherService.getWeather(city, "16c2ab3566ef6b743455f314d26530dd", "metric");
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    WeatherResponse weatherResponse = response.body();
                    updateWeatherInfo(weatherResponse);
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                // Handle failure
            }
        });
    }

    private void updateWeatherInfo(WeatherResponse weatherResponse) {
        weatherDescription.setText(weatherResponse.weather.get(0).description);
        temperature.setText(String.format(Locale.getDefault(), "%.2f °C", weatherResponse.main.temp));
        humidity.setText(String.format(Locale.getDefault(), "%d%%", weatherResponse.main.humidity));
        weatherCard.setVisibility(View.VISIBLE);
    }
}