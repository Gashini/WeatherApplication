package com.example.weatherapplication;

public @interface SerializedName {
}
